<?php
/**
 * @param $skipp_from_deletion
 * @param $import
 */
function pmwi_wp_all_import_skipped_from_deleted( $skipp_from_deletion, $import ){

}